<script>
  
  document.getElementById("loginForm").addEventListener("submit", function(event) {
      event.preventDefault(); // Prevent form submission

      // Redirect to dashboard.html
      window.location.href = "http://127.0.0.1:5500/dashbord.html"; // Ensure this file exists
  });



   <!-- Signup Modal -->

   <script>
    // Redirect to signup.html when the Sign Up button is clicked
    document.addEventListener("DOMContentLoaded", function () {
      const signupButton = document.getElementById("signupButton"); // Adjust ID if necessary
  
      if (signupButton) {
        signupButton.addEventListener("click", function () {
          window.location.href = "signup.html"; // Redirect to signup.html
        });
      }
    });
  </script>

<script>
  // Redirect to dashboard.html when the Create Account button is clicked
  document.addEventListener("DOMContentLoaded", function () {
    const createAccountButton = document.getElementById("createAccountButton"); // Adjust ID if necessary

    if (createAccountButton) {
      createAccountButton.addEventListener("click", function (event) {
        event.preventDefault(); // Prevent form submission
        window.location.href = "dashboard.html"; // Redirect to dashboard.html
      });
    }
  });
</script>

  



// Modal functionality
<script>

  // Form submissions
  document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault();
    // Add login logic here
    console.log('Login submitted');
  });

  document.querySelector('.contact-form').addEventListener('submit', function(e) {
    e.preventDefault();
    // Add contact form logic here
    console.log('Contact form submitted');
  });
</script>
</body>
</html>

<script>
// Smooth scrolling behavior
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      window.scrollTo({
        top: target.offsetTop - 50, // Adjust offset for fixed navbar
        behavior: 'smooth'
      });
    }
  });
});
</script>
</body>
